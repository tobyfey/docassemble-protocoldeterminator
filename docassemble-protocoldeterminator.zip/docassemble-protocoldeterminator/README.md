The protocoldeterminator docassemble extension is intended to help intake staff and community partners identify potential referrals and information for relevant courts and housing types.

Protocols are written in a yaml file.